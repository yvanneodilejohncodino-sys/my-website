# My GitHub Pages Website

This is a five-page HTML website prepared for GitHub Pages.

## Pages

- `index.html` — Home page
- `about_me.html` — About Me
- `Gallary.html` — Art Gallery
- `student_resource_page.html` — Web Development Resources
- `accessible_registration_form.html` — Workshop Registration

## GitHub Pages

Upload these files to the root of a GitHub repository.

Then go to:

Repository → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save

The site will use `index.html` as its homepage.

## Navigation

All five pages use `index.html` for the Home link.
